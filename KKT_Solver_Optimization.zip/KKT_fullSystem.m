function F = KKT_fullSystem(z, f, h, g, n, m, l, active_indices)
    x = z(1:n);
    r = length(active_indices);
    mu_active = z(n+1:n+r);
    lambda = z(n+r+1:end);

    grad_f = numerical_gradient(f, x);
    grad_h = numerical_jacobian(h, x);  % m×n
    grad_g = numerical_jacobian(g, x);  % l×n
    g_vals = g(x);
    h_vals = h(x);

    gradL = grad_f;
    if m > 0
        gradL = gradL + grad_h' * lambda;
    end
    if r > 0
        gradL = gradL + grad_g(active_indices,:)' * mu_active;
    end

    F = [gradL; h_vals; g_vals(active_indices)];
end