function grad = numerical_gradient(f, x)
    n = length(x);
    grad = zeros(n,1);
    h = 1e-6;
    for i = 1:n
        x1 = x;
        x2 = x;
        x1(i) = x1(i) - h;
        x2(i) = x2(i) + h;
        grad(i) = (f(x2) - f(x1)) / (2*h);
    end
end