clc;
clear;

fprintf('--- KKT Solver for Nonlinear Constrained Optimization ---\n');

while true
    n = input('Enter number of variables (n): ');
    m = input('Enter number of equality constraints (m): ');
    l = input('Enter number of inequality constraints (l): ');

    f = input('Enter objective function f as a function handle of x (e.g., @(x)[...]):\nf(x) = ');
    h = input('Enter equality constraint function h as a vector-valued function (e.g., @(x)[h1; h2; ...]):\nh(x) = ');
    g = input('Enter inequality constraint function g as a vector-valued function (e.g., @(x)[g1; g2; ...]):\ng(x) = ');

    x0 = input(sprintf('Enter initial guess x0 (vector of length %d):\n', n));

    solutions = KKT(f, h, g, x0);

    if ~isempty(solutions)
        fprintf('\n--- Summary of Valid KKT Points Found ---\n');
        for i = 1:length(solutions)
            sol = solutions(i);
            fprintf('\nKKT Point #%d:\n', i);
            fprintf('x* = [%s]\n', num2str(sol.x'));
            fprintf('f(x*) = %.6f\n', sol.fval);
            fprintf('Active Set: %s\n', mat2str(sol.activeSet));
        end
    end

    choice = lower(input('\nDo you want to solve another problem? (y/n): ', 's'));
    if choice ~= 'y'
        fprintf('Exiting KKT Solver. Goodbye!\n');
        break;
    end
end
