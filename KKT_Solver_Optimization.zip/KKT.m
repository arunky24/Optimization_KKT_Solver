function solutions = KKT(f, h, g, x0)
    n = length(x0);
    m = length(h(x0));
    l = length(g(x0));
    active_sets = dec2bin(0:2^l - 1) - '0';

    found = false;
    solutions = [];

    for i = 1:size(active_sets, 1)
        active = logical(active_sets(i, :));
        fprintf('\n--- Trying Active Set: %s ---\n', mat2str(find(active)));

        try
            [x_star, lambda, mu, iterCount] = solveKKT(f, h, g, active, x0, n, m, l);
            g_vals = g(x_star);
            h_vals = h(x_star);
            comp_vals = mu' .* g_vals';

            % === LICQ Check Start ===
            grad_h = numerical_jacobian(h, x_star);     % m × n matrix
            grad_g = numerical_jacobian(g, x_star);     % l × n matrix
            grad_g_active = grad_g(active, :);          % select active inequality rows
            GradMatrix = [grad_h; grad_g_active];       % combine equality + active inequality gradients

            r = rank(GradMatrix);
            num_constraints = size(GradMatrix, 1);

            if r == num_constraints
                fprintf('🔹 LICQ holds at this point (rank = %d)\n', r);
            else
                fprintf('🔸 LICQ fails at this point (rank = %d < %d)\n', r, num_constraints);
            end
            % === LICQ Check End ===

            fprintf('x* = [%s]\n', num2str(x_star'));
            fprintf('f(x*) = %.6f\n', f(x_star));
            fprintf('lambda = [%s]\n', num2str(lambda'));
            fprintf('mu = [%s]\n', num2str(mu'));
            fprintf('g(x*) = [%s]\n', num2str(g_vals'));
            fprintf('h(x*) = [%s]\n', num2str(h_vals'));
            fprintf('mu .* g = [%s]\n', num2str(comp_vals));
            fprintf('Number of iterations: %d\n', iterCount);

            isFeasible = all(abs(h_vals) < 1e-6) && all(g_vals <= 1e-6);
            isComplementary = all(abs(comp_vals) < 1e-6);
            isNonNegMu = all(mu >= -1e-6);

            if isFeasible && isComplementary && isNonNegMu
                fprintf('✅ Valid KKT point found!\n');
                found = true;
                solutions = [solutions; struct('x', x_star, 'lambda', lambda, 'mu', mu, ...
                                'fval', f(x_star), 'g', g_vals, 'h', h_vals, ...
                                'activeSet', find(active))];
            else
                fprintf('❌ Not a valid KKT point\n');
            end
        catch ME
            fprintf('❌ Combination %s failed: %s\n', mat2str(find(active)), ME.message);
        end
    end

    if ~found
        fprintf('\nNo valid KKT points found.\n');
    end
end
