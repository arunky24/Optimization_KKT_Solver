function [x_star, lambda_val, mu_full, iterCount] = solveKKT(f, h, g, active_set, x0, n, m, l)
    A = find(active_set);        % Active inequality indices
    r = length(A);               % Number of active inequalities

    vars0 = [x0; ones(r,1); zeros(m,1)];

    eqns = @(vars) KKT_fullSystem(vars, f, h, g, n, m, l, A);

    options = optimoptions('fsolve', 'Display', 'off', ...
        'FunctionTolerance', 1e-9, 'StepTolerance', 1e-9);

    [sol, ~, ~, output] = fsolve(eqns, vars0, options);

    x_star = sol(1:n);
    mu_active = sol(n+1:n+r);
    lambda_val = sol(n+r+1:end);

    mu_full = zeros(l,1);
    mu_full(A) = mu_active;
    iterCount = output.iterations;
end