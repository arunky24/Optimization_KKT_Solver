function J = numerical_jacobian(F, x)
    n = length(x);
    Fx = F(x);
    m = length(Fx);
    J = zeros(m,n);
    h = 1e-6;
    for i = 1:n
        x1 = x;
        x2 = x;
        x1(i) = x1(i) - h;
        x2(i) = x2(i) + h;
        J(:,i) = (F(x2) - F(x1)) / (2*h);
    end
end
